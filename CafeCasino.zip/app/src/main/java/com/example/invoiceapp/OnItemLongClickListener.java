package com.example.invoiceapp;

/**
 * Interface definition for a callback to be invoked when an item in a RecyclerView is
 * long-clicked.
 */
public interface OnItemLongClickListener<T> {
    /**
     * Called when an item has been long-clicked.
     * @param callbackItem callback Object item.
     */
    void onItemLongClick(T callbackItem);
}