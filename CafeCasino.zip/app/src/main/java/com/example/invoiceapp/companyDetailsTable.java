package com.example.invoiceapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

public class companyDetailsTable {
    private final SQLiteDatabase database;

    /** Inner class that defines the table contents */
    private static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "CompanyDetails";
        public static final String COMPANY_NAME = "CompanyName";
        public static final String COMPANY_ADDRESS = "CompanyAddress";
        public static final String COMPANY_NUMBER = "CompanyNumber";
        public static final String COMPANY_ID = "CompanyID";
    }

    /** Query for create the table */
    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + FeedEntry.TABLE_NAME + " ( " +
                    FeedEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    FeedEntry.COMPANY_NAME + " TEXT NOT NULL ," +
                    FeedEntry.COMPANY_ADDRESS + " TEXT NOT NULL ," +
                    FeedEntry.COMPANY_NUMBER + " TEXT NOT NULL ," +
                    FeedEntry.COMPANY_ID + " TEXT NOT NULL UNIQUE);";

    public static String getTableName() {
        return FeedEntry.TABLE_NAME;
    }

    public companyDetailsTable(SQLiteDatabase database) {
        this.database = database;
    }

    public boolean SetCompany(CompanyDetails companyDetails) {
        boolean success = false;
        ContentValues values = new ContentValues();
        values.put(FeedEntry.COMPANY_NAME, companyDetails.getCompanyName());
        values.put(FeedEntry.COMPANY_ADDRESS, companyDetails.getCompanyAddress());
        values.put(FeedEntry.COMPANY_NUMBER, companyDetails.getCompanyNumber());
        values.put(FeedEntry.COMPANY_ID, companyDetails.getCompanyId());
        database.beginTransaction();
        try {
              long result = database.insert(FeedEntry.TABLE_NAME, null, values);
              if (result == -1) success = false;
              if (success) database.setTransactionSuccessful();
        }
        catch (Exception e) { success = false; }
        finally { database.endTransaction(); }
        return success;
    }

    public boolean UpdateCompany(CompanyDetails companyDetails) {
        ContentValues values = new ContentValues();
        values.put(FeedEntry.COMPANY_NAME, companyDetails.getCompanyName());
        values.put(FeedEntry.COMPANY_ADDRESS, companyDetails.getCompanyAddress());
        values.put(FeedEntry.COMPANY_NUMBER, companyDetails.getCompanyNumber());
        values.put(FeedEntry.COMPANY_ID, companyDetails.getCompanyId());
        String selection = FeedEntry._ID + " LIKE ?";
        String[] selectionArgs = { String.valueOf(1) };
        return database.update(
                FeedEntry.TABLE_NAME,   // The table to update
                values,                 // The new values to update
                selection,              // The WHERE clause
                selectionArgs           // The value (_ID) for the WHERE clause
        ) > 0;
    }

    public CompanyDetails getCompany() {
        return null;
    }

    public boolean deleteCompany() {
        if (database == null) return false;
        return database.delete(FeedEntry.TABLE_NAME, "ID = 1", null) > 0;
    }
}
