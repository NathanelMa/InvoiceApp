package com.example.invoiceapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class InvoiceManagerDialog {

    /**
     * This class help the activity InvoiceManager:
     * 1. Display the full invoice in dialog.
     * 2. User query for remove confirmation.
     * 3. User query for edit.
     * NOTE: This class does not interaction with database.
     */

    private final List<Item> allItemsList;
    private final Context context;
    private static SimpleDateFormat dateFormat;

    private final int ROW_TEXT_SIZE = 12;
    private final int PADDING_LEFT_RIGHT = 2;

    public InvoiceManagerDialog(List<Item> allItemsList, Context context) {
        this.allItemsList = allItemsList;
        this.context = context;
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    }

    /**
     * Display the given invoiceFrame, using data from both invoiceFrame (invoiceID, date, total),
     * and invoiceRow (Each row including: itemID, item value (single item), amount of items)
     * @param invoiceFrame InvoiceFrame 'Frame' - ID, date (dd-MM-yyyy) and total value.
     * @param invoiceRows All rows for this invoiceFrame.
     */
    @SuppressLint("SetTextI18n")
    public void displayInvoice(InvoiceFrame invoiceFrame, List<InvoiceRow> invoiceRows) {
        View dialogView = LayoutInflater.from(this.context)
                .inflate(R.layout.activity_invoice_manager_dialog_invoice, null);
        LinearLayout dialogInvoiceLayout = dialogView.findViewById(R.id.invoice_layout);

        long invoiceID = invoiceFrame.getID();
        double invoicePrice = invoiceFrame.getTotalPrice();
        String formattedDate = invoiceFrame.getDate();

        // Set header for this invoiceFrame
        TextView tvID = dialogInvoiceLayout.findViewById(R.id.table_invoice_ID);
        TextView tvTotalPrice = dialogInvoiceLayout.findViewById(R.id.table_invoice_total);
        TextView tvDate = dialogInvoiceLayout.findViewById(R.id.table_invoice_date);
        tvID.setText("#" + String.format(Locale.getDefault(), "%010d", invoiceID));
        tvTotalPrice.setText(String.format(Locale.getDefault(), "%.2f", invoicePrice));
        tvDate.setText(formattedDate);

         // Setup invoiceFrame Rows
        for (InvoiceRow invoiceRow : invoiceRows) {
            LinearLayout rowLayout = createInvoiceRowLayout(
                    invoiceRow.getItemID(),
                    invoiceRow.getItemValue(),
                    invoiceRow.getQuantity(),
                    invoiceRow.getTotalRowValue());
            dialogInvoiceLayout.addView(rowLayout);
        }

        Dialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .setPositiveButton("OK", null)
                .create();
        dialog.show();
    }

    /**
     * Create text column in the layout (invoice table)
     * @param text Text present
     * @param weight Weight in the invoice table
     * @return TextView type for the invoice display.
     */
    private TextView createTextView(String text, int weight) {
        TextView textView = new TextView(this.context);
        textView.setText(text);
        textView.setLayoutParams(new LinearLayout.LayoutParams
                (0, LinearLayout.LayoutParams.WRAP_CONTENT, weight));
        textView.setTextSize(ROW_TEXT_SIZE);
        textView.setPadding(2, 5, 2, 5);
        return textView;
    }

    private LinearLayout createInvoiceRowLayout(long itemID, double itemPrice,
                                                int itemQuantity, double totalRowPrice) {
        LinearLayout rowLayout = new LinearLayout(this.context);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
        rowLayout.setPadding(PADDING_LEFT_RIGHT, 12, PADDING_LEFT_RIGHT, 12);

        int itemID_index = (int) itemID;
        rowLayout.addView(createTextView(String.valueOf(itemID), 1));
        rowLayout.addView(createTextView(
                String.valueOf(this.allItemsList.get(itemID_index - 1).getName()), 3));
        rowLayout.addView(createTextView(FormatUtils.formatCurrency(itemPrice), 1));
        rowLayout.addView(createTextView(String.valueOf(itemQuantity), 1));
        rowLayout.addView(createTextView(
                String.format(Locale.getDefault(),"%.2f", totalRowPrice), 1));

        return rowLayout;
    }

    public void shareInvoiceFrame(InvoiceFrame invoiceFrame, List<InvoiceRow> rows) {
        PDFGenerator.shareInvoicePdf(this.context,
                PDFGenerator.createInvoicePdf(this.context, invoiceFrame, rows));
    }

    public void printInvoiceFrame(InvoiceFrame invoiceFrame, List<InvoiceRow> rows) {
        PDFGenerator.printInvoicePdf(this.context, invoiceFrame, rows);
    }

    /**
     * Displays a dialog for editing selected invoice
     * @param callback Callback to notify the calling activity of success or failure:
     *                 onSuccess for editing the invoice.
     *                 onFailure for cancel or invalid data.
     */
    public void displayEditItemDialog(Item prevItem, DialogCallback<Item> callback) {
        return; /// TODO
    }

    /**
     * Displays a dialog for confirmation remove selected invoice
     * @param callback Callback to notify the calling activity of success or failure:
     *                 onSuccess for remove the invoice.
     *                 onFailure for cancel only.
     */
    public void displayRemoveItemDialog(Item prevItem, DialogCallback<Integer> callback) {
        return; /// TODO
    }

    /** Start date piker dialog */
    public void datePickerDialog(DialogCallback<String> callback) {
        final Calendar calendarInstance = Calendar.getInstance();
        int year = calendarInstance.get(Calendar.YEAR);
        int month = calendarInstance.get(Calendar.MONTH);
        int day = calendarInstance.get(Calendar.DAY_OF_MONTH);

        // Set listener for the dialog
        DatePickerDialog.OnDateSetListener onDateSetListener
                = (datePicker, selectedYear, selectedMonth, selectedDay) -> {
            calendarInstance.set(Calendar.YEAR, selectedYear);
            calendarInstance.set(Calendar.MONTH, selectedMonth);
            calendarInstance.set(Calendar.DAY_OF_MONTH, selectedDay);
            @SuppressLint("DefaultLocale") String selectedDate = selectedYear + "-" +
                    String.format("%02d",selectedMonth +
                            1,Locale.getDefault()) + "-" + selectedDay;
            callback.onSuccess(selectedDate);
        };

        DatePickerDialog datePickerDialog = new DatePickerDialog(this.context,
                android.R.style.Theme_Material_Dialog,
                onDateSetListener, year, month, day);
        Objects.requireNonNull(datePickerDialog.getWindow());
        datePickerDialog.show();
    }
}
