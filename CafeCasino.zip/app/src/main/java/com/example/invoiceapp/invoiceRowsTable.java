package com.example.invoiceapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class invoiceRowsTable {

    private final SQLiteDatabase sqLiteDatabase;

    /** Inner class that defines the table contents */
    private static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "InvoiceRows";
        public static final String INVOICE_ID = "InvoiceID";
        public static final String ITEM_ID = "ItemID";
        public static final String VALUE = "Value";
        public static final String AMOUNT = "Amount";
    }

    /** Query for create the table */
    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + FeedEntry.TABLE_NAME + " ( " +
                    FeedEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    FeedEntry.INVOICE_ID + " INTEGER NOT NULL," +
                    FeedEntry.ITEM_ID + " INTEGER NOT NULL," +
                    FeedEntry.VALUE +	" REAL NOT NULL," +
                    FeedEntry.AMOUNT + " INTEGER NOT NULL);";

    /**
     * Removing the selected (by invoiceIDs) rows, and return all IDs that has been removed.
     * @param invoiceIDs Selected rows by ID to remove from table.
     * @return Set of all invoice IDs successfully removed from the table. If null, no success,
     *          Or empty Set.
     */
    public @NonNull Set<Integer> removeRows(@NonNull Set<Integer> invoiceIDs) {
        if (invoiceIDs.isEmpty()) return new HashSet<>();
        Set<Integer> removedIDs = new HashSet<>();
        boolean success = true;

        // Go over the IDs, if deleted, adding to the HashSet
        sqLiteDatabase.beginTransaction();
        try {
            for (Integer invoiceID : invoiceIDs) {
                String selection = FeedEntry.INVOICE_ID + " = ?";
                String[] selectionArgs = { String.valueOf(invoiceID) };
                try {
                    if (sqLiteDatabase.delete(FeedEntry.TABLE_NAME, selection, selectionArgs) > 0)
                        removedIDs.add(invoiceID);
                }
                catch (Exception e) {
                    Log.e("DBrows", e.toString());
                    success = false;
                    break;
                }
            }
            if (success) { sqLiteDatabase.setTransactionSuccessful(); }
        } finally { sqLiteDatabase.endTransaction(); }
        return removedIDs;
    }

    public static String getTableName() {
        return FeedEntry.TABLE_NAME;
    }

    public invoiceRowsTable(SQLiteDatabase db) {
        this.sqLiteDatabase = db;
    }

    /**
     * Add rows into the table, inserted with their InvoiceID
     * @param rows List of InvoiceItem
     * @param invoiceID (long) invoiceID
     * @return True if success
     */
    public boolean addInvoiceRows(List<InvoiceRow> rows, long invoiceID) {
        boolean success = true;
        sqLiteDatabase.beginTransaction();
        try {
            for (InvoiceRow r : rows) {
                ContentValues values = new ContentValues();
                values.put(FeedEntry.INVOICE_ID, invoiceID);
                values.put(FeedEntry.ITEM_ID, r.getItemID());
                values.put(FeedEntry.VALUE, r.getTotalRowValue());
                values.put(FeedEntry.AMOUNT, r.getQuantity());
                long result = sqLiteDatabase.insert(FeedEntry.TABLE_NAME, null, values);
                if (result == -1) success = false;
            }
            if (success) sqLiteDatabase.setTransactionSuccessful();
        }
        catch (Exception e) { success = false; }
        finally { sqLiteDatabase.endTransaction(); }
        return success;
    }

    /**
     * Get all invoice rows, given the unique invoice frame ID
     * @param invoiceID Common ID for all requested rows in this table.
     * @return List of InvoiceRow (implements InvoiceItem)
     */
    public @NonNull List<InvoiceRow> getAllRowsByID(long invoiceID, List<Item> itemList) {
        List<InvoiceRow> invoiceList = new ArrayList<>();

        String[] columns = {
                FeedEntry.ITEM_ID,
                FeedEntry.VALUE,
                FeedEntry.AMOUNT
        };

        String selection = FeedEntry.INVOICE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(invoiceID) };

        Cursor cursor = sqLiteDatabase.query(
                FeedEntry.TABLE_NAME,  //
                columns,               //
                selection,             // WHERE
                selectionArgs,         // condition values
                null,                  // groupBy
                null,                  // having
                null                   // orderBy
        );

        while (cursor.moveToNext()) {
            long itemID = cursor.getLong(cursor.getColumnIndexOrThrow(FeedEntry.ITEM_ID));
            double totalPriceRow = cursor.getDouble(cursor.getColumnIndexOrThrow(FeedEntry.VALUE));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(FeedEntry.AMOUNT));
            double itemPrice = 0;
            if (quantity == 0) itemPrice = 0;
            itemPrice = totalPriceRow / quantity;

            Item tempItem = null;

            if ((int) itemID - 1 >= itemList.size()) {
                tempItem = new Item(itemID, "Item Removed", "Item Removed", itemPrice);
            }
            else {
                int fixedIndex = (int) itemID - 1;
                long tempID = itemList.get(fixedIndex).getID();
                if (tempID == itemID) {
                    tempItem = new Item(
                            itemID,
                            itemList.get(fixedIndex).getName(),
                            itemList.get(fixedIndex).getDescription(),
                            itemPrice);
                }
            }
            invoiceList.add(new InvoiceRow(invoiceID, quantity, tempItem));
        }
        cursor.close();
        return invoiceList;
    }


}
