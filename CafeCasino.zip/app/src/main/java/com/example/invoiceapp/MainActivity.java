package com.example.invoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button buttonInvoices, buttonItems, buttonGraphs;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.home_info) {
            Toast.makeText(this, "TODO info for operation", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Home");  /// This title for the option menu only

        this.buttonItems = findViewById(R.id.home_items_button);
        this.buttonInvoices = findViewById(R.id.home_invoices_button);
        this.buttonGraphs = findViewById(R.id.home_graphs_button);

        this.buttonItems.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.super.getBaseContext(), ItemsActivity.class);
            startActivity(intent);
        });

        this.buttonInvoices.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.super.getBaseContext(), InvoiceManagerActivity.class);
            startActivity(intent);
        });
    }
}