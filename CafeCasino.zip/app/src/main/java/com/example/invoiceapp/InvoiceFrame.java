package com.example.invoiceapp;

import androidx.annotation.NonNull;

import java.util.Objects;

public class InvoiceFrame implements Comparable<InvoiceFrame> {
    private final String date;
    private final double totalValue;
    private final long ID;

    /**
     * Compose invoice frame including unique ID, date and value.
     * @param ID Unique ID
     * @param date Formatted: yyyy-mm-dd hh:mm:ss
     * @param totalValue Double for total value for this invoice
     */
    public InvoiceFrame(long ID, @NonNull String date, double totalValue) {
        this.date = date;
        this.totalValue = totalValue;
        this.ID = ID;
    }

    /**
     * Get invoice frame created date, format: "yyyy-MM-dd hh:mm:ss"
     * @return String, formated date
     */
    public String getDate() {
        return this.date;
    }

    /**
     * @return Get total price for this invoice
     */
    public double getTotalPrice() {
        return this.totalValue;
    }

    /**
     * @return Get the unique invoice ID as in database
     */
    public long getID() {
        return this.ID;
    }

    /**
     * @return Get as date formated: ?
      */
    public String getCreationDate() {
        return this.date;
    }

    public boolean isEmpty() {
        return date.isEmpty() && totalValue <= 0;
    }

    @Override
    public int compareTo(InvoiceFrame invoiceItem) {
        return Long.compare(this.getID(), invoiceItem.getID());
    }

    @NonNull
    @Override
    public String toString() {
        return  getID() + " " + getCreationDate() + " " + getTotalPrice();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InvoiceFrame)) return false;
        InvoiceFrame that = (InvoiceFrame) o;
        return ID == that.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ID);
    }

    @NonNull
    @Override
    public InvoiceFrame clone() {
        InvoiceFrame clone;
        try {
            clone = (InvoiceFrame) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        return clone;
    }
}
