package com.example.invoiceapp;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity for displaying and managing a list of items.
 * This activity allows users to view, add, edit, sort, and remove items.
 * It uses a RecyclerView to display the items stored in an SQLite database.
 */
public class ItemsActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private List<Item> itemsList;   // List of all items in data base sorted by user options
    private RecyclerView itemsRecyclerView;
    private RVAdapterItems RVAdapterItems;

    /// Icons ID to unable toggle options (Sort by name / value of items)
    int id_icon_sorted_name, id_icon_sorted_name_selected,
            id_icon_sorted_value, id_icon_sorted_value_selected;
    boolean sortedByName = false,
            sortedByPrice = false;

    /**
     * Inflates the menu options in the toolbar.
     * @param menu The menu to be inflated.
     * @return True if the menu was successfully created.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_items_manager, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Handles menu item selection. Menu included:
     * Edit item by selection, adding new item, remove selected items, sorted by price,
     * sorted by name or both, home page (Activity) and option 'more' (Dropdown for no room items).
     * @param item The selected menu item.
     * @return True if the action was handled.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.item_manager_home) {
            finish();  // End the activity
            return true;
        }
        if (itemID == R.id.item_manager_edit_item) {
            editItem();
            return true;
        }
        if (itemID == R.id.item_manager_add_item) {
            addItem();
            return true;
        }
        if (itemID == R.id.item_manager_remove_selected) {
            removeSelectedItems();
            return true;
        }
        if (itemID == R.id.item_manager_sorted_name) {
            // Toggle option using boolean
            if (!sortedByName) item.setIcon(this.id_icon_sorted_name_selected);
            else item.setIcon(this.id_icon_sorted_name);
            sortedByName = !sortedByName;
            updateItemsList();
            return true;
        }
        if (itemID == R.id.item_manager_sorted_value) {
            // Toggle option using boolean
            if (!sortedByPrice) item.setIcon(this.id_icon_sorted_value_selected);
            else item.setIcon(this.id_icon_sorted_value);
            sortedByPrice = !sortedByPrice;
            updateItemsList();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Called when the activity is first created. Initializes UI components.
     * Notice the upper casting: List type InvoiceItem, getting Item list.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items_manager);
        setIconsIDs();
        this.setTitle("");  // This title for the option menu only
        this.databaseHelper = DatabaseHelper.getInstance(getApplicationContext());
        this.itemsList = new ArrayList<>(databaseHelper.getAllItems(sortedByName, sortedByPrice));
        if (itemsList.isEmpty()) popAlertNoItems();
        setupRecyclerView();
    }

    /** Sets up the RecyclerView with its adapter and grid (2 in row) layout manager. */
    private void setupRecyclerView() {
        this.RVAdapterItems = new RVAdapterItems(itemsList, this, false);
        this.itemsRecyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager linearLayoutManager = new GridLayoutManager
                (this, 2,RecyclerView.VERTICAL, false);
        this.itemsRecyclerView.setLayoutManager(linearLayoutManager);
        this.itemsRecyclerView.setAdapter(this.RVAdapterItems);
        this.itemsRecyclerView.setClipToPadding(true);
        TextView textInfoActivity = findViewById(R.id.items_activity_info);
        textInfoActivity.setText("" + itemsList.size() + " Total items");
    }

    /**
     * Initializes icon IDs.
     */
    private void setIconsIDs() {
        this.id_icon_sorted_name = R.drawable.items_sorted_by_name;
        this.id_icon_sorted_name_selected = R.drawable.items_sorted_by_name_selected;
        this.id_icon_sorted_value = R.drawable.items_sorted_by_price;
        this.id_icon_sorted_value_selected = R.drawable.items_sorted_by_price_selected;
    }

    /**
     * Will update the RVAdapterItems and the itemsList for refresh the activity after:
     * Sorting, editing, adding new item or removing selected items.
     * Notice the upper casting from List type Item to List type InvoiceItem.
     */
    private void updateItemsList() {
        itemsList.clear();
        itemsList = new ArrayList<>(databaseHelper.getAllItems(sortedByName, sortedByPrice));
        if (itemsList.isEmpty()) popAlertNoItems();

        else {
            // Notify the adapter about the updated list
            this.RVAdapterItems = new RVAdapterItems(itemsList, this, false);
            this.itemsRecyclerView = findViewById(R.id.recycler_view);
            this.itemsRecyclerView.setAdapter(this.RVAdapterItems);
        }
    }

    /**
     * Displays an alert dialog when no items are found in the database.
     */
    private void popAlertNoItems() {
        new AlertDialog.Builder(this)
                .setMessage("No items found in database.\nYou can add them.")
//                .setCancelable(false).setPositiveButton("OK", (dialog, which) -> null)
                .show();
    }

    /**
     * Prompts the user to confirm item removal and removes selected items if confirmed.
     */
    private void removeSelectedItems() {
        List<Item> selectedItems = RVAdapterItems.getSelectedItems();
        ItemsDialogHelper.displayConfirmRemovingItemDialog(this,
                selectedItems, new DialogCallback<Item>() {
            @Override
            public void onSuccess(Item item) {
                // NOTE: the return item is null
                for (Item selctedItem : selectedItems) {
                    if (!databaseHelper.removeItem(selctedItem.getID())) {
                        Log.i("ItemsActivity", "Removing selected item failed: ID: "
                                + item.getID());
                    }
                }
                updateItemsList();
                Toast.makeText(ItemsActivity.this, "SELECTED ITEMS REMOVED",
                        Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onFailure(String failMSG) {
                Toast.makeText(ItemsActivity.this, failMSG, Toast.LENGTH_SHORT).show();
            }
        });

    }

    /** Opens a dialog for adding a new item */
    private void addItem() {
        ItemsDialogHelper.displayNewItemDialog(ItemsActivity.this, new DialogCallback<Item>() {
            @Override
            public void onSuccess(Item item) {
                if (databaseHelper.addNewItem(item)) {
                    Toast.makeText(ItemsActivity.this, "ITEM ADDED",
                            Toast.LENGTH_SHORT).show();
                    updateItemsList();
                }
            }
            @Override
            public void onFailure(String failMSG) {
                Toast.makeText(ItemsActivity.this, failMSG, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Opens a dialog for editing a selected item.
     */
    private void editItem() {
        Item prevItem = RVAdapterItems.getSelectedItem();

        // Get the selected item from RVAdapterItems, pop dialog with this argument,
        // and when DialogCallBack onSuccess is called, catch the updated item with the same ID,
        // and call the database helper for edit.

        if (prevItem == null) {
            Toast.makeText(this, "SELECT ONE ITEM", Toast.LENGTH_SHORT).show();
            return;
        }

        ItemsDialogHelper.displayEditItemDialog(ItemsActivity.this,
                prevItem, new DialogCallback<Item>() {
            @Override
            public void onSuccess(Item item) {
                if (databaseHelper.editItem(item)) {
                    Toast.makeText(ItemsActivity.this, "ITEM EDITED",
                            Toast.LENGTH_SHORT).show();
                    updateItemsList();
                } else
                    Toast.makeText(ItemsActivity.this, "FAIL EDITING",
                            Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String failMSG) {
                Toast.makeText(ItemsActivity.this, failMSG, Toast.LENGTH_SHORT).show();
            }
        });
    }
}