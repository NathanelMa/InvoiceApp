package com.example.invoiceapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import java.util.ArrayList;
import java.util.List;

public class itemsTable {
    private final SQLiteDatabase database;

    /** Inner class that defines the table contents */
    private static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "BasicItem";
        public static final String NAME = "Name";
        public static final String DESCRIPTION = "Description";
        public static final String VALUE = "Value";
    }

    /** Query for create the table */
    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + FeedEntry.TABLE_NAME + " ( " +
                    FeedEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    FeedEntry.NAME + " TEXT NOT NULL UNIQUE," +
                    FeedEntry.DESCRIPTION + " TEXT," +
                    FeedEntry.VALUE + " REAL NOT NULL);";

    public static String getTableName() {
        return FeedEntry.TABLE_NAME;
    }

    public itemsTable(SQLiteDatabase db) {
        this.database = db;
    }

    /**
     * Removing Item by it's ID. Return if success
     * @param ID unique Item ID.
     * @return True if removed.
     */
    public boolean RemoveItem(long ID) {
        try {
            String selection = FeedEntry._ID + " = ?";
            String[] selectionArgs = { String.valueOf(ID) };
            long deletedRows = database.delete(FeedEntry.TABLE_NAME, selection, selectionArgs);
            return deletedRows > 0;
        }
        catch (Exception e) { return false; }
    }

    /**
     * Add new Item to the table.
     * @param newItem The new Item to add
     */
    public boolean addItem(Item newItem) {
        ContentValues values = new ContentValues();
        values.put(FeedEntry.DESCRIPTION, newItem.getDescription());
        values.put(FeedEntry.VALUE, newItem.getValue());
        values.put(FeedEntry.NAME, newItem.getName());
        return database.insert(FeedEntry.TABLE_NAME, null, values) >= 0;
    }

    /**
     * Update item, keep the same ID number for it.
     * @param updatedItem with the same ID as before.
     * @return True if success.
     */
    public boolean editItem(Item updatedItem) {
        if (updatedItem.getID() <= 0 ) return false;

        ContentValues values = new ContentValues();
        values.put(FeedEntry.NAME, updatedItem.getName());
        values.put(FeedEntry.DESCRIPTION, updatedItem.getDescription());
        values.put(FeedEntry.VALUE, updatedItem.getValue());

        /// Update only where the _id matches the itemID
        String selection = FeedEntry._ID + " LIKE ?";
        String[] selectionArgs = { String.valueOf(updatedItem.getID()) };
        return database.update(
                FeedEntry.TABLE_NAME,   // The table to update
                values,                 // The new values to update
                selection,              // The WHERE clause
                selectionArgs           // The value (_ID) for the WHERE clause
        ) > 0;
    }

    /**
     * Get an Item from table by ID or by name. If by ID, keep name empty.
     * @param ID long, ID of the Item.
     * @param itemName Name of the Item. Keep empty if get by ID.
     * @return Item type, will contain all details for the Item.
     */
    public Item getItem(long ID, String itemName) {
        int rowIdIndex, valueIndex, nameIndex, descriptionIndex;
        Item resItem = null;
        Cursor cursor = null;

        if (itemName.isEmpty()) {
            String query = "SELECT * FROM " + FeedEntry.TABLE_NAME + " WHERE " + FeedEntry._ID + " = ?";
            cursor = database.rawQuery(query, new String[]{String.valueOf(ID)});
        }
        else {
            String query = "SELECT * FROM " + FeedEntry.TABLE_NAME + " WHERE " + FeedEntry.NAME + " = ?";
            cursor = database.rawQuery(query, new String[]{itemName});
        }

        if (cursor.moveToFirst()) {
            rowIdIndex = cursor.getColumnIndex(FeedEntry._ID);
            valueIndex = cursor.getColumnIndex(FeedEntry.VALUE);
            nameIndex = cursor.getColumnIndex(FeedEntry.NAME);
            descriptionIndex = cursor.getColumnIndex(FeedEntry.DESCRIPTION);

            if (valueIndex != -1 && nameIndex != -1 && descriptionIndex != -1) {
                resItem = new Item(
                        cursor.getInt(rowIdIndex),
                        cursor.getString(nameIndex),
                        cursor.getString(descriptionIndex),
                        cursor.getInt(valueIndex));
            }
            cursor.close();
        }
        return resItem;
    }

    /**
     * Get all items, sorted by name or by price or both.
     * If both false, will return the list of items sorted by ID (last added).
     * @param byName boolean, sorted by names.
     * @param byPrice boolean, sorted by prices.
     * @return List (ArrayList) of items. Order as mention
     */
    public List<Item> getItems(boolean byName, boolean byPrice) {
        List<Item> itemsList = new ArrayList<>();
        String orderBy;

        if (byName && byPrice) orderBy = FeedEntry.NAME + " ASC, " + FeedEntry.VALUE+ " ASC";
        // First name then price order
        else if (byName) orderBy = FeedEntry.NAME + " ASC";
        else if (byPrice) orderBy = FeedEntry.VALUE + " ASC";
        else orderBy = FeedEntry._ID + " ASC";  // Default order

        // SQL query
        Cursor cursor = database.query(
                FeedEntry.TABLE_NAME,
                new String[]{FeedEntry._ID, FeedEntry.NAME, FeedEntry.DESCRIPTION, FeedEntry.VALUE},
                null,
                null,
                null,
                null,
                orderBy
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String description = cursor.getString(2);
            double value = cursor.getDouble(3);
            itemsList.add(new Item(id, name, description, value));
        }
        cursor.close();
        return itemsList;
    }
}
