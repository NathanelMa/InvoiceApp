package com.example.invoiceapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import org.intellij.lang.annotations.Identifier;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

final class DatabaseHelper extends SQLiteOpenHelper {

    /**
     * Data base helper for manging 3 tables:
     * itemsTable, invoiceRowsTable and invoicesFramesTable.
     * NOTE: Private constructor to prevent direct instantiation, Make call to static method
     * "getInstance()" instead.
     * All return object handle, type @param InvoiceItem
     */

    private static final String DATABASE_NAME = "invoices.db";
    private static final int DATABASE_VERSION = 1;
    private static DatabaseHelper INSTANCE;

    private itemsTable itemsTable;
    private invoiceRowsTable invoiceRowsTable;
    private invoicesFramesTable invoicesFramesTable;
    private companyDetailsTable companyDetailsTable;

    /** Private constructor to prevent direct instantiation, and prevent multiple
     * instances from being created. Make call to static method "getInstance()" instead. */
    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        initializeTables();
    }

    /** Init tables if needed */
    private void initializeTables() {
        if (itemsTable == null) {
            itemsTable = new itemsTable(getWritableDatabase());
        }
        if (invoiceRowsTable == null) {
            invoiceRowsTable = new invoiceRowsTable(getWritableDatabase());
        }
        if (invoicesFramesTable == null) {
            invoicesFramesTable = new invoicesFramesTable(getWritableDatabase());
        }
        if (companyDetailsTable == null) {
            companyDetailsTable = new companyDetailsTable((getWritableDatabase()));
        }
    }

    /**
     * Create an accesses to database and it's operations.
     * @param context Context type, use *application context* and not activity.
     * @return Instance of DatabaseHelper - Will have all operation for database.
     */
    public static DatabaseHelper getInstance(Context context) {
        /*
         * Use the application context as suggested by CommonsWare.
         * this will ensure that we don't accidentally leak (memory) an Activity context.
         */
        if (INSTANCE == null) {
            INSTANCE = new DatabaseHelper(context.getApplicationContext());
        }
        return INSTANCE;
    }

    /**
     * This method is only run when the database file did not exist and was just created.
     * If onCreate() returns successfully (doesn't throw an exception),
     * the database is assumed to be created with the requested version number.
     * @param database DataBase.
     */
    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(com.example.invoiceapp.itemsTable.SQL_CREATE_ENTRIES);
        database.execSQL(com.example.invoiceapp.invoiceRowsTable.SQL_CREATE_ENTRIES);
        database.execSQL(com.example.invoiceapp.invoicesFramesTable.SQL_CREATE_ENTRIES);
        database.execSQL(com.example.invoiceapp.companyDetailsTable.SQL_CREATE_ENTRIES);
    }

    /**
     * This method is only called when the database file exists but the stored version number is
     * lower than requested in the constructor. The onUpgrade() should update the table schema
     * to the requested version. In this case will drop all tables.
     * @param database The database.
     * @param i The old database version.
     * @param i1 The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase database, int i, int i1) {
        database.execSQL("DROP TABLE IF EXISTS " + com.example.invoiceapp.itemsTable.getTableName());
        database.execSQL("DROP TABLE IF EXISTS " + com.example.invoiceapp.invoiceRowsTable.getTableName());
        database.execSQL("DROP TABLE IF EXISTS " + com.example.invoiceapp.invoicesFramesTable.getTableName());
        database.execSQL("DROP TABLE IF EXISTS " + com.example.invoiceapp.companyDetailsTable.getTableName());
        onCreate(database);
    }


    /*//////////////////////////////////////////////////////////////////////////////////////////////
    ItemTable   ////////////////////////////////////////////////////////////////////////////////////
    /*//////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Adding new item to the database. Doesn't provide invalidation item input data.
     * @param item InvoiceItem. Must contain: Value, Name.
     * @return True if successes.
     */
    public boolean addNewItem(Item item) {
        return this.itemsTable.addItem(item);
    }

    /**
     * Edit current item from data base. Doesn't provide invalidation item input data.
     * @param item InvoiceItem. ID same as in database.
     * @return True if successes.
     */
    public boolean editItem(Item item) {
        return this.itemsTable.editItem(item);
    }

    /**
     * Remove item from database, using his unique ID.
     * @param ID long itemID as field ID in InvoiceItem
     * @return True if successes.
     */
    public boolean removeItem(long ID) {
        return this.itemsTable.RemoveItem(ID);
    }

    /**
     * Get all the list of item found in data base. If no items were found, return empty
     * list. Default, by increasing order (ID). Choose otherwise.
     * @param byName Order data in list, by names.
     * @param byPrice Order data in list, by values.
     * @return List of items, type Item, implement InvoiceItem.
     */
    public List<Item> getAllItems(boolean byName, boolean byPrice) {
        return this.itemsTable.getItems(byName, byPrice);
    }


    /*//////////////////////////////////////////////////////////////////////////////////////////////
    invoiceRowsTable ///////////////////////////////////////////////////////////////////////////////
    /*//////////////////////////////////////////////////////////////////////////////////////////////

    public @NonNull List<InvoiceRow> getAllRowsByID(long invoiceID) {
        if (invoiceID <= 0) return new ArrayList<>();
        List<Item> allItem = getAllItems(false, false);
        return this.invoiceRowsTable.getAllRowsByID(invoiceID, allItem);
    }

    /*//////////////////////////////////////////////////////////////////////////////////////////////
    invoicesFramesTable   //////////////////////////////////////////////////////////////////////////
    /*//////////////////////////////////////////////////////////////////////////////////////////////

    /// Each composing/edit the order: Compose frame -> Successes ? -> Add all rows.
    /// Safe edit: See docstring for the safety.
    /// NOTE: All invoice calculation made here, not in the table helper classes,
    /// including composing time.

    /**
     * Return the invoice frame by his UNIQUE ID as found in database
     * @param ID UNIQUE ID invoiceFrame
     * @return Invoice frame. Null if non found.
     */
    public InvoiceFrame getInvoiceById(int ID) {
        return this.invoicesFramesTable.getInvoiceById(ID);
    }

    /**
     * Removing all frame along with their matching rows, given the Set of UNIQUE IDs.
     * If desired only one frame to remove, input into the Set the single ID.
     * Safe deleting: For each removed set of rows in the InvoiceRows, delete the match frame.
     * @param IDs UNIQUE IDs of invoices
     * @return True if all success.
     */
    public boolean RemoveInvoiceFrames(@NonNull Set<Integer> IDs) {
        if (IDs.isEmpty()) return false;
        // Remove rows, return Set is all IDs that has been successfully removed.
        Set<Integer> successIDsRemoved = this.invoiceRowsTable.removeRows(IDs);
        // If Set is not empty, next: Remove all matching invoiceFrame.
        if (!successIDsRemoved.isEmpty())
            return this.invoicesFramesTable.RemoveInvoiceFrames(IDs);
        else return false;
    }

    /**
     * Edit invoice frame - All safe operation.
     * First Removing rows -> Successes? -> edit frame and adding new rows.
     * Safe Edit for safe edit. If any fail, any reason, the old rows will be kept in database.
     * @param ID invoice UNIQUE ID for the invoice frame matching the new rows
     * @param NewInvoiceRows New rows, replace instead of the excited rows.
     * @return True if all safe edited. Any fail, the old rows will be kept in database.
     */
    public boolean editInvoice(int ID, @NonNull List<InvoiceRow> NewInvoiceRows) {
        String fullDateEdit = FormatUtils.getCurrentTimestamp();
        if (ID <= 0 || NewInvoiceRows.isEmpty() || fullDateEdit.isEmpty()) return false;

        // Remove all rows by given ID. Set contain only one ID (@NoNull)
        // First safe save copy.
        List<InvoiceRow> safeCopy = getAllRowsByID(ID);
        Set<Integer> successIDsRemoved = this.invoiceRowsTable.removeRows(Collections.singleton(ID));

        // After removing all rows, edit the selected InvoiceFrame.
        // If successes add the new rows, with the same ID
        // Double check for ID for safe transaction.

        boolean successes = false;
        if (!successIDsRemoved.isEmpty() && successIDsRemoved.contains(ID)) {
            double totalPrice = 0;
            for (InvoiceRow r: NewInvoiceRows) totalPrice += r.getTotalRowValue();
            successes = this.invoicesFramesTable.EditInvoiceFrame(fullDateEdit, totalPrice, ID);
            if (successes)
                return this.invoiceRowsTable.addInvoiceRows(NewInvoiceRows, ID);
            else if (!safeCopy.isEmpty())
                addComposedInvoice(safeCopy);
        }
        return false;
    }

    /**
     * Add composed list of invoice rows to the invoiceRowsTable.
     * Date format "yyyy-MM-dd 00:00:00"
     * @param invoiceRows List type InvoiceRow extend InvoiceItem
     * @return True for success transaction.
     */
    public boolean addComposedInvoice(@NonNull List<InvoiceRow> invoiceRows) {
        String fullDate = FormatUtils.getCurrentTimestamp();
        if (invoiceRows.isEmpty() || fullDate.isEmpty()) return false;

        try { FormatUtils.formatDateFull(fullDate); }
        catch (ParseException e) { return false; }

        double totalPriceInvoice = 0;
        for (InvoiceRow row: invoiceRows) totalPriceInvoice += row.getTotalRowValue();
        long InvoiceFrameID = this.invoicesFramesTable.addNewInvoiceFrame(fullDate, totalPriceInvoice);

        // Check fail insert Frame
        if (InvoiceFrameID <= 0) return false;

        // Safe insert all rows with the correct InvoiceFrameID as inserted before
        return this.invoiceRowsTable.addInvoiceRows(invoiceRows, InvoiceFrameID);
    }

    /**
     * Get the next invoiceID as shown in the invoicesFramesTable.
     * @return long invoice ID unique
     */
    public long getNextInvoiceID() {
        return this.invoicesFramesTable.getNewInvoiceID();
    }

    /**
     * Get all recent (by date) of all invoice as in the invoicesFramesTable.
     * Each ID matching invoice Row in the invoiceRowsTable.
     * @return List of invoice type InvoiceItem
     */
    public List<InvoiceFrame> getByRecentInvoices() {
        return this.invoicesFramesTable.getRecentInvoices();
    }

    /**
     * Search all frame by given date.
     * @param date Search for frame by this date.
     * @return List of all frame founded in database.
     */
    public List<InvoiceFrame> getInvoicesByDate(String date) {
        return this.invoicesFramesTable.getInvoicesByDate(date);
    }

    /**
     * Get all frames from database (Without InvoiceRows) sorted be selected.
     * @param sortedByValue Sort by value.
     * @param sortedByRecent Sort by date.
     * @return List of all invoice frames
     */
    public List<InvoiceFrame> getAllInvoicesFrames(boolean sortedByValue, boolean sortedByRecent) {
        List<InvoiceFrame> invoices = this.invoicesFramesTable.getAllInvoices();
        if (invoices == null || invoices.isEmpty()) {
            return invoices;
        }
        if (sortedByRecent) {
            Collections.sort(invoices, new Comparator<InvoiceFrame>() {
                @Override
                public int compare(InvoiceFrame i1, InvoiceFrame i2) {
                    return i2.getDate().compareTo(i1.getDate());
                }
            });
        } else if (sortedByValue) {
            Collections.sort(invoices, new Comparator<InvoiceFrame>() {
                @Override
                public int compare(InvoiceFrame i1, InvoiceFrame i2) {
                    return Double.compare(i1.getTotalPrice(), i2.getTotalPrice());
                }
            });
        }
        return invoices;
    }
}