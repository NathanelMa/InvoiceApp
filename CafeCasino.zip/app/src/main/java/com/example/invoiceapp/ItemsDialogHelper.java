package com.example.invoiceapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import java.util.List;

/**
 * Dialog offer 2 methods: Updating item or adding a new item.
 * Both responsible for layout and interaction including msg display for each action.
 * All methods are static, no need to init instance.
 * NOTE: No operation on database. All method are static.
 */
public class ItemsDialogHelper {

    /**
     * Private constructor, use the static methods
     */
    private ItemsDialogHelper() {
        // Private constructor, use the static methods
    }

    /**
     * Displays a dialog for adding new item. If the operation is
     * successful, the callback's onSuccess is called with the new item.
     * Otherwise, onFailure is called.
     * @param context  Activity context.
     * @param callback Callback to notify the calling activity of success or failure.
     */
    public static void displayNewItemDialog(Context context, DialogCallback<Item> callback) {
        View dialogView = LayoutInflater.from(context).
                inflate(R.layout.activity_items_manager_dialog, null);

        EditText editItemName = dialogView.findViewById(R.id.items_dialog_item_name);
        EditText editDescription = dialogView.findViewById(R.id.items_dialog_item_description);
        EditText editPrice = dialogView.findViewById(R.id.items_dialog_item_price);

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .setPositiveButton("ADD", null)
                .setNegativeButton("CANCEL", null)
                .create();
        dialog.show();

        // Positive button logic

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String itemDescription = editDescription.getText().toString().trim();
            String itemPrice = editPrice.getText().toString().trim();

            if (!itemName.isEmpty() && !itemDescription.isEmpty() && !itemPrice.isEmpty()) {
                Object test = Item.checkValidData(itemName, itemDescription, itemPrice);
                if (test instanceof Item) {
                    Item tempItem = (Item) test;
                    callback.onSuccess(tempItem);
                    dialog.dismiss();
                }
                else {
                    editDescription.setText("");
                    editItemName.setText("");
                    editPrice.setText("");
                    Toast.makeText(context, (String) test, Toast.LENGTH_SHORT).show();
                }
            }
            else Toast.makeText(context, "Please fill all item detail", Toast.LENGTH_SHORT).show();
        });

        // Negative button logic

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            callback.onFailure("CANCELED");
            dialog.dismiss();
        });
    }

    /**
     * Displays a dialog for editing selected item.
     * @param context  Activity context.
     * @param callback Callback to notify the calling activity of success or failure.
     */
    public static void displayEditItemDialog(Context context, Item prevItem, DialogCallback<Item> callback) {
        View dialogView = LayoutInflater.from(context).
                inflate(R.layout.activity_items_manager_dialog, null);

        TextView title = dialogView.findViewById(R.id.items_dialog_title);
        title.setText("Edit item");

        EditText editItemName = dialogView.findViewById(R.id.items_dialog_item_name);
        EditText editDescription = dialogView.findViewById(R.id.items_dialog_item_description);
        EditText editPrice = dialogView.findViewById(R.id.items_dialog_item_price);

        editItemName.setText(prevItem.getName());
        editDescription.setText(prevItem.getDescription());
        editPrice.setText(String.valueOf(prevItem.getValue()));

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .setPositiveButton("EDIT", null)
                .setNegativeButton("CANCEL", null)
                .create();
        dialog.show();

        // Positive button logic
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String itemDescription = editDescription.getText().toString().trim();
            String itemPrice = editPrice.getText().toString().trim();

            if (!itemName.isEmpty() && !itemDescription.isEmpty() && !itemPrice.isEmpty()) {
                Object test = Item.checkValidData(itemName, itemDescription, itemPrice, prevItem.getID());
                if (test instanceof Item) {
                    Item tempItem = (Item) test;
                    callback.onSuccess(tempItem);
                    dialog.dismiss();
                }
                else {
                    editItemName.setText(prevItem.getName());
                    editDescription.setText(prevItem.getDescription());
                    editPrice.setText(String.valueOf(prevItem.getValue()));
                    Toast.makeText(context, (String) test, Toast.LENGTH_SHORT).show();
                }
            }
            else Toast.makeText(context, "Please fill all item fields", Toast.LENGTH_SHORT).show();
        });

        // Negative button logic
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            callback.onFailure("CANCELED");
            dialog.dismiss();
        });
    }

    /**
     * Display dialog with the names of selected items for cancel or confirm removing.
     * OnSuccess, callback will contain null item.
     * @param context   Activity context.
     * @param selectedItems List of the selected items.
     * @param callback  Callback to notify the calling activity of success or failure.
     */
    public static void displayConfirmRemovingItemDialog(Context context, List<Item> selectedItems,
                                                        DialogCallback<Item> callback) {

        // Check if the selected contain at least one item
        if (selectedItems.isEmpty())
            callback.onFailure("NO SELECTED ITEMS TO REMOVE");

        // Else, wait to confirmation from user for removing, and do if so.
        else {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < selectedItems.size(); i++)  {
                stringBuilder.append(selectedItems.get(i).getName());
                if (i + 1 != selectedItems.size()) stringBuilder.append(", ");
            }

            AlertDialog dialog = new AlertDialog.Builder(context)
                    .setMessage(stringBuilder.toString())
                    .setTitle("")
                    .setPositiveButton("REMOVE", null)
                    .setNegativeButton("CANCEL", null)
                    .create();

            dialog.setOnShowListener(d -> {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    callback.onSuccess(null);
                    dialog.dismiss();
                });

                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                    callback.onFailure("CANCELED");
                    dialog.dismiss();
                });
            });
            dialog.show();
        }

    }
}
