package com.example.invoiceapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * This activity allow the user composing a new/edit invoice using selection from current items.
 * At the end, if the user choose to save the invoice, it will be save into database.
 * User can remove selected rows, reduces selected rows, or add automatic to excited item.
 */
public class InvoiceComposingActivity extends AppCompatActivity {

    /*
        If init for edit:
            It will draw all data from database, based on the invoice ID.
            Safe Operation in Database only:
                after composing/edit rows, when choose to save the current edited invoice,
                it will remove all related data from database, and place with the same ID.
                Also, removed for the invoice frame itself, and added it with the same ID.
            Safe operation in this activity:
                if user cancel, nothing will be change.
     */

    /// TODO Dialog for config ending
    /// TODO finish double
    /// TODO Long press for enter new quantity

    private DatabaseHelper databaseHelper;
    private List<InvoiceRow> composedInvoiceRows;
    private List<Item> itemsList;

    /// Temp selected values (Item, Amount) are update live according the user
    private double totalComposedInvoicePrice;
    private long currentInvoiceID;
    private Item selectedItem;
    private int selectedQuantity;
    private int totalNumberItems;
    private boolean isActivityForEdit;

    /// GUI elements
    private RVAdapterInvoiceRows RVAdapter;
    private Spinner spinnerAddItem;
    private EditText editQuantity;
    private TextView totalPriceItemTempTV, totalNumberItemsTV;
    private TextView totalComposedInvoicePriceTV;

    /**
     * Called when the activity is first created. Initializes UI components.
     * @param savedInstanceState Prev instance state
     */
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_composing);
        this.setTitle("Invoice Composing");

        this.databaseHelper = DatabaseHelper.getInstance(getApplicationContext());
        this.currentInvoiceID = databaseHelper.getNextInvoiceID();
        this.itemsList = this.databaseHelper.getAllItems(true, true);

        if (this.itemsList == null)
            Toast.makeText(this, "No items found in database", Toast.LENGTH_SHORT).show();

        // Check if asked if edit invoice
        Intent intent = getIntent();
        long requestedInvoiceID = intent.getLongExtra("InvoiceFrameID", -1);
        if (requestedInvoiceID != -1) {
            this.setTitle("Invoice Edit");
            this.isActivityForEdit = InitActivityForEdit(requestedInvoiceID);
        }

        // If not for edit, init normal composing invoice from screech
        if (!this.isActivityForEdit) {
            this.composedInvoiceRows = new LinkedList<>();
            this.totalNumberItems = 0;
            this.totalComposedInvoicePrice = 0;
        }
        setupRecyclerView();
        setupCard();
    }

    /**
     * Init activity for edit an invoice frame
     * @param editInvoiceID ID for patching the frame and the rows.
     * @return True if the rows available
     */
    private boolean InitActivityForEdit(long editInvoiceID) {
        // @NoNull return value from DB
        this.composedInvoiceRows = this.databaseHelper.getAllRowsByID(editInvoiceID);
        if (composedInvoiceRows.isEmpty()) return false;
        this.totalNumberItems = this.composedInvoiceRows.size();
        this.currentInvoiceID = editInvoiceID;
        this.totalComposedInvoicePrice = 0;
        for (InvoiceRow row: composedInvoiceRows)
            totalComposedInvoicePrice += row.getTotalRowValue();
        return true;
    }

    /**
     * Each time submit a new list, ListAdapter runs DiffUtil on a background thread to
     * compute the difference between the new list and the old list: Any change.
     */
    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    private void updateInvoiceChange() {
        this.totalNumberItemsTV.setText("Total items: "
                + FormatUtils.formatInteger(this.totalNumberItems));
        RVAdapter.notifyDataSetChanged();
    }

    private void removeRow(int composedRowIndex) {
        if (composedRowIndex < 0) return;
        InvoiceRow targetRow = composedInvoiceRows.get(composedRowIndex);
        if (targetRow == null) return;

        if (targetRow.getQuantity() == 0)
            addComposedTotalPrice(-1 * targetRow.getItemValue());
        else addComposedTotalPrice(-1 * targetRow.getTotalRowValue());

        Toast.makeText(this, targetRow.getItemName() + " Removed",
                Toast.LENGTH_SHORT).show();
        composedInvoiceRows.remove(composedRowIndex);
        this.totalNumberItems--;
    }

    /**
     * Search the item (selectedItemSpinner type item) within the composedInvoice,
     * If there is existed item on the composed list, just add the quantity typed by user.
     */
    @SuppressLint("SetTextI18n")
    private void addRow() {
        boolean addNewRow = false; // Check if new row, or update
        InvoiceRow newInvoiceRow = null;
        int index = Collections.binarySearch(this.composedInvoiceRows, this.selectedItem);
        // Found the sorted index for new row
        if (index < 0) {
            index = -(index + 1);
            newInvoiceRow = new InvoiceRow(
                    this.currentInvoiceID,       // Note for each row is the same invoiceID
                    this.selectedQuantity,          // Selected amount for item
                    this.selectedItem);             // Selected item
            this.composedInvoiceRows.add(index, newInvoiceRow);
            this.totalNumberItems++;
            addComposedTotalPrice(newInvoiceRow.getTotalRowValue());
            addNewRow = true;
        }
        // Else, there is no such item on the composed list, add new one.
        else {
            addComposedTotalPrice(this.selectedQuantity * this.selectedItem.getValue());
            newInvoiceRow = this.composedInvoiceRows.get(index);
            newInvoiceRow.addQuantity(this.selectedQuantity);
        }
        updateInvoiceChange();
        if (addNewRow) this.RVAdapter.clearSelection();
    }

    /**
     * Remove selected items, can be done with multiple rows.
     * If no selected items, notify the user.
     * @SuppressLint Because of multiply selection, all data set changed.
     */
    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    private void removeSelectedItems() {
        Set<Integer> targetItems = this.RVAdapter.getSelectedPositions();
        if (targetItems == null)
            Toast.makeText(this, "SELECT ONE ROW FOR REMOVE", Toast.LENGTH_SHORT).show();

        else if (targetItems.isEmpty())
            Toast.makeText(this, "SELECT ONE ROW FOR REMOVE", Toast.LENGTH_SHORT).show();

        else for (int indexSelected: targetItems) {
            if (indexSelected >= composedInvoiceRows.size()) continue;
            else removeRow(indexSelected);
        }
        this.RVAdapter.clearSelection();
        updateInvoiceChange();
    }

    /**
     * Before using make sure updating the 'selectedItem' and the 'selectedQuantity'.
     * Updating the row of total price for selected item and the selected amount of it.
     * Note: This is not the added row price.
     */
    private void updateItemTempPrice() {
        double totalPriceItemTemp = this.selectedItem.getValue() * this.selectedQuantity;
        this.totalPriceItemTempTV.setText(FormatUtils.formatCurrency(totalPriceItemTemp));
    }

    /**
     * Update the total value of this composed invoice, add can be negative or positive.
     * Does not sync with the 'totalPriceItemTemp'.
     */
    private void addComposedTotalPrice(double add) {
        this.totalComposedInvoicePrice += add;
        this.totalComposedInvoicePriceTV.setText
                (FormatUtils.formatCurrency(this.totalComposedInvoicePrice));
    }

    /**
     * Reduce the quantity of selected rows. If the quantity of one of them is zero,
     * remove it and notify the recyclerViewAdapterBasicItems. If no selected items, notify the user.
     * It can be done with multiple rows.
     */
    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    private void reduceSelectedItemQuantity() {
        Set<Integer> targetItems = this.RVAdapter.getSelectedPositions();
        if (targetItems == null)  {
            Toast.makeText(this, "SELECT ONE ROW FOR CHANGE", Toast.LENGTH_SHORT).show();
            return;
        };
        if (targetItems.isEmpty()) {
            Toast.makeText(this, "SELECT ONE ROW FOR CHANGE", Toast.LENGTH_SHORT).show();
            return;
        }

        for (int indexSelected: targetItems) {
            if (indexSelected >= composedInvoiceRows.size()) continue;
            InvoiceRow targetRow = composedInvoiceRows.get(indexSelected);
            if (targetRow == null) continue;
            else composedInvoiceRows.get(indexSelected).reduceQuantity();
            // Remove if quantity is zero, else reduce
            if (targetRow.getQuantity() == 0) {
                removeRow(indexSelected);
                RVAdapter.clearSelection();
            }
            else addComposedTotalPrice(-1 * targetRow.getItemValue());
        }
        updateInvoiceChange();
    }

    private void setupCard() {
        TextView invoiceID_TextView = findViewById(R.id.invoice_ID);
        Button addItemsButton = findViewById(R.id.adding_button);
        FloatingActionButton createInvoiceButton = findViewById(R.id.composing_invoice_create_button);
        FloatingActionButton cancelInvoiceButton
                = findViewById(R.id.composing_invoice_cancel_button);

        invoiceID_TextView.setText(FormatUtils.formatSerialNumber(this.currentInvoiceID));
        this.totalPriceItemTempTV = findViewById(R.id.textview_total_price_item_added);
        this.totalComposedInvoicePriceTV = findViewById(R.id.textview_total_price_invoice);
        this.totalNumberItemsTV = findViewById(R.id.textview_total_items);
        this.spinnerAddItem = findViewById(R.id.spinner_items);
        this.editQuantity = findViewById(R.id.edit_quantity);
        this.selectedQuantity = 0;
        this.totalNumberItemsTV.setText("Total items: 0");
        this.totalComposedInvoicePriceTV.setText(FormatUtils.formatCurrency(this.totalComposedInvoicePrice));

        /// Setup quantity listener
        editQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {;}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {;}
            @Override
            public void afterTextChanged(Editable s) {
                try {
                    selectedQuantity = Integer.parseInt(s.toString());
                    if (selectedQuantity <= 0) throw new Exception();
                    selectedItem = (Item) spinnerAddItem.getSelectedItem();
                    updateItemTempPrice();
                }
                catch (Exception e) {
                    editQuantity.setError("TYPE AGAIN"); // Display hint error for non-integer
                }
            }
        });

        /// Setup spinner for items from database
        ArrayAdapter<Item> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, this.itemsList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spinnerAddItem.setAdapter(adapter);

        /// Setup spinner listener
        spinnerAddItem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView,
                                       View selectedItemView, int position, long id) {
                // Getting at position return Object type. Safe casting
                selectedItem = (Item) parentView.getItemAtPosition(position);
                updateItemTempPrice();
                ((TextView) parentView.getChildAt(0)).setTextColor(getResources().getColor(R.color.Navy));
                ((TextView) parentView.getChildAt(0)).setTextSize(30);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {;}
        });

        /// Setup add row button listener
        addItemsButton.setOnClickListener(view -> {
            if (this.selectedQuantity <= 0) return;
            addRow();
        });

        /// Setup cancel and create listener
        cancelInvoiceButton.setOnClickListener(view -> {
            Toast.makeText(this, "CANCELED", Toast.LENGTH_SHORT).show();
            finish();
        });

        createInvoiceButton.setOnClickListener(view -> {
            if (composedInvoiceRows.isEmpty() && !isActivityForEdit)
                Toast.makeText(this, "EMPTY CARD", Toast.LENGTH_SHORT).show();
            else composeInvoice();
        });
    }

    /** Sets up the RecyclerView with its adapter and layout manager. */
    private void setupRecyclerView() {
        RecyclerView RV = findViewById(R.id.recycler_view);
        this.RVAdapter = new RVAdapterInvoiceRows(this);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        RV.setLayoutManager(linearLayoutManager);
        RV.setAdapter(this.RVAdapter);
        this.RVAdapter.submitList(this.composedInvoiceRows);
    }

    /**
     * Create the invoice frame from the composedInvoiceRows composed by user.
     * Finish the activity at the end.
     */
    private void composeInvoice() {
        List<InvoiceRow> copyComposedList = new ArrayList<>(this.composedInvoiceRows);
        boolean succses = false;
        String msg = "Fail composing";
        // If init for edit, call database for edit else for normal save - and see if success
        if (this.isActivityForEdit)
            if (composedInvoiceRows.isEmpty()) {
                // Ask for removing the current invoice
                //
            }
            else succses = databaseHelper.editInvoice((int) this.currentInvoiceID, copyComposedList);
        else
            succses = (databaseHelper.addComposedInvoice(copyComposedList));

        if (succses) msg = "SAVED";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, InvoiceManagerActivity.class);
        startActivity(intent);
        finish();
    }

    /** Suppress BackPressed from user, in order to prevent data lost on composed invoice. */
    @SuppressLint("MissingSuperCall")
    public void onBackPressed() {
        // Suppress back call from user
    }

    /**
     * Inflates the menu options in the toolbar.
     * @param menu The menu to be inflated.
     * @return True if the menu was successfully created.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_invoice_composing, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Handles menu invoice composing.
     * @param m The selected menu item.
     * @return True if the action was handled.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem m) {
        if (m.getItemId() == R.id.invoice_composing_reduce_amount) {
            reduceSelectedItemQuantity();
            return true;
        }
        if (m.getItemId() == R.id.invoice_composing_remove_row) {
            removeSelectedItems();
            return true;
        }
        return super.onOptionsItemSelected(m);
    }
}