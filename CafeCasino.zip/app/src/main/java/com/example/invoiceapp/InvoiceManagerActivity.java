package com.example.invoiceapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * InvoiceRow manager for adding and display invoice from database.
 * This activity allow user the following operation with invoices:
 * 1. Look for invoice by number (invoiceID).
 * 2. Show all invoice by given date.
 * 3. Composing a new invoice - Starting a new activity.
 * 4. Print/Sharing selected (full) invoice frame.
 */
public class InvoiceManagerActivity extends AppCompatActivity {

    /*
        The activity hold the main list type invoice frame (ID, date, total).
        Secondary list, type invoice frame, for search result.
        Singleton search result by ID as well.
     */

    /// Data
    private DatabaseHelper database;
    private List<InvoiceFrame> allInvoiceFrames;

    /// GUI Elements
    private Snackbar snackbar;
    private TextView editDate;
    private LinearLayoutManager gridLayoutManagerRV;
    private SearchView searchView;
    private String selectedDate;
    private ImageButton sortByRecentButton, sortByValueButton;
    private RVAdapterInvoiceFrame RVAdapter; // Adapter for the GUI
    private InvoiceManagerDialog invoiceManagerDialog; // Dialog helper for different operation

    /// /// Icons ID to unable toggle options (Sort by name / value of items)
    private int selectedFilterIcon, unselectedFilterIcon;
    boolean sortedByRecent = false, sortedByValue = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_manager);
        this.setTitle("Invoices Manager");

        this.selectedDate = "";
        this.database = DatabaseHelper.getInstance(getApplicationContext());
        this.invoiceManagerDialog = new InvoiceManagerDialog(
                database.getAllItems(false, false), this);
        this.allInvoiceFrames = database.getByRecentInvoices();

        String msg = "No invoice found in database";
        if (this.allInvoiceFrames != null)
            if (!this.allInvoiceFrames.isEmpty())
                msg = "Found " + this.allInvoiceFrames.size() + " Invoices";
        displaySnackBar(msg);

        setupRecyclerView();
        setupDatePicker();
        setupSearchByID();
        setupSortingOptions();
        setupFloatingButtonComposeInvoice();
        setUpRemove();
        setupClearSelection();
        setupEditInvoice();
    }

    /** Display msg as SnackBar */
    private void displaySnackBar(String msg) {
        this.snackbar = Snackbar.make(findViewById(android.R.id.content), msg,
                Snackbar.LENGTH_LONG).setAction("OK", v -> { }); snackbar.show();
    }

    private void removeSelectedInvoices() {
        StringBuilder msgAllRemoved = new StringBuilder("Invoice ID:\n");
        Set<Integer> IDs = new TreeSet<>();
        for (int selectedIndex: this.RVAdapter.getSelectedPositions()) {
            IDs.add((int) allInvoiceFrames.get(selectedIndex).getID());
            msgAllRemoved.append(
                    FormatUtils.formatSerialNumber(allInvoiceFrames.get(selectedIndex).getID()))
                    .append(" - ");
        }
        if (this.database.RemoveInvoiceFrames(IDs)) {
            setResultBy();
            msgAllRemoved.append("All removed!");
            this.snackbar = Snackbar.make(findViewById(android.R.id.content), msgAllRemoved,
                    Snackbar.LENGTH_LONG).setAction("OK", v -> { }); snackbar.show();
        }

    }

    private void setupClearSelection() {
        ImageButton clearButton = findViewById(R.id.button_clear_selection);
        clearButton.setOnClickListener(v -> {
            if (this.RVAdapter.isSelectedEmpty())
                Toast.makeText(this ,"No selected invoices", Toast.LENGTH_SHORT).show();
            else this.RVAdapter.clearSelection();
        });
    }

    /** Toggle button for recent sort option - Setup color and boolean variable */
    private void toggleSortedRecent() {
        sortByRecentButton.setColorFilter(selectedFilterIcon, PorterDuff.Mode.SRC_IN);
        if (!sortedByRecent)
            sortByRecentButton.setColorFilter(selectedFilterIcon, PorterDuff.Mode.SRC_IN);
        else sortByRecentButton.setColorFilter(unselectedFilterIcon, PorterDuff.Mode.SRC_IN);
        sortedByRecent = !sortedByRecent;
    }

    /** Toggle button for values sort option - Setup color and boolean variable */
    private void toggleSortedValue() {
        sortByValueButton.setColorFilter(selectedFilterIcon, PorterDuff.Mode.SRC_IN);
        if (!sortedByValue)
            sortByValueButton.setColorFilter(selectedFilterIcon, PorterDuff.Mode.SRC_IN);
        else sortByValueButton.setColorFilter(unselectedFilterIcon, PorterDuff.Mode.SRC_IN);
        sortedByValue = !sortedByValue;
    }

    /** Reset both sorting option button (Only buttons, not the data) */
    private void resetToggleOption() {
        if (sortedByRecent) toggleSortedRecent();
        if (sortedByValue) toggleSortedValue();
    }

    /** Set the main list sorted as toggled */
    private void setResultBy() {
        this.allInvoiceFrames = this.database.getAllInvoicesFrames(sortedByValue, sortedByRecent);
        int currentPosition = gridLayoutManagerRV.findFirstVisibleItemPosition();
        this.RVAdapter.submitList(allInvoiceFrames,() -> gridLayoutManagerRV.scrollToPosition(currentPosition));
        this.RVAdapter.clearSelection();
    }

    /** Setup search option */
    private void setupSearchByID() {
        this.searchView = findViewById(R.id.invoice_manager_search_bar);
        Button searchByIDButton = findViewById(R.id.invoice_manager_search_id_button);
        searchByIDButton.setOnClickListener(v -> { searchByID(); });
    }

    /** Search the current search ID and update the 'searchResultInvoices' list */
    @SuppressLint("SetTextI18n")
    private void searchByID() {
        resetToggleOption();
        this.editDate.setText("DD/MM/YYYY"); // Reset the date search
        String query = searchView.getQuery().toString();
        if (!query.isEmpty()) {
            try {
                int invoiceID = Integer.parseInt(query);
                String msgRes = "No invoice found, by ID: " + invoiceID;
                // Frame searched by user
                InvoiceFrame invoiceFrameResID = null;
                invoiceFrameResID = database.getInvoiceById(invoiceID);
                if (invoiceFrameResID != null)
                    RVAdapter.submitList(Collections.singletonList(invoiceFrameResID));
                else {
                    this.snackbar = Snackbar.make(findViewById(android.R.id.content), msgRes,
                            Snackbar.LENGTH_LONG).setAction("OK", v -> { }); snackbar.show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid ID", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** Set recycler view with the long click listener calling showDialogFullInvoice */
    private void setupRecyclerView() {
        this.RVAdapter = new RVAdapterInvoiceFrame(this);
        // GUI element for display all invoice frames
        RecyclerView itemsRecyclerView = findViewById(R.id.recycler_view);
        this.gridLayoutManagerRV = new GridLayoutManager
                (this, 2,RecyclerView.VERTICAL, false);
        itemsRecyclerView.setLayoutManager(gridLayoutManagerRV);
        itemsRecyclerView.setAdapter(this.RVAdapter);
        this.RVAdapter.submitList(this.allInvoiceFrames);
        this.gridLayoutManagerRV.setOrientation(RecyclerView.VERTICAL);
        this.gridLayoutManagerRV.setSmoothScrollbarEnabled(true);
        this.gridLayoutManagerRV.scrollToPosition(0);
        // Set show full invoice
        this.RVAdapter.setOnItemLongClickListener(this::showFullInvoice);
    }

    /**
     * Set up sorting options: Sort by recent/value.
     * Updating RVAdapter list as well.
     */
    private void setupSortingOptions() {
        this.sortByRecentButton = findViewById(R.id.button_sort_recent);
        this.sortByValueButton = findViewById(R.id.button_sort_price);
        this.selectedFilterIcon =
                getApplicationContext().getResources().getColor(R.color.Yellow);
        this.unselectedFilterIcon =
                getApplicationContext().getResources().getColor(R.color.white);
        // Set listeners
        sortByValueButton.setOnClickListener(view -> {
            toggleSortedValue();
            setResultBy();
        });
        sortByRecentButton.setOnClickListener(v -> {
            toggleSortedRecent();
            setResultBy();
        });
    }

    /** Setup dialog for date search by user */
    @SuppressLint("SetTextI18n")
    private void setupDatePicker() {
        this.editDate = findViewById(R.id.invoice_manager_date_textview);
        this.editDate.setText("DD/MM/YYYY");
        editDate.setOnClickListener(v -> {
            invoiceManagerDialog.datePickerDialog(new DialogCallback<String>() {
                @Override
                public void onSuccess(String callbackItem) {
                    selectedDate = callbackItem;
                    try { editDate.setText(FormatUtils.formatDateForDisplay(selectedDate)); }
                    catch (ParseException e) { e.fillInStackTrace(); }
                }
                @Override
                public void onFailure(String failMSG) {;}
            }); });

        Button datePickerDialog = findViewById(R.id.invoice_manager_date_piker_button);
        datePickerDialog.setOnClickListener(view -> { searchByDate(); });
    }

    /** Search by date all invoices frame. Updating 'resultByDateList'. */
    private void searchByDate() {
        resetToggleOption();
        searchView.setQuery("", false);
        searchView.clearFocus();
        String msgRes = "No invoice found " + selectedDate;

        if (selectedDate != null && !selectedDate.isEmpty()) {
            List<InvoiceFrame> filteredInvoices = database.getInvoicesByDate(selectedDate);
            if (filteredInvoices != null && !filteredInvoices.isEmpty()) {
                msgRes = "Found " + filteredInvoices.size() + " Invoices";
                // All frames searched by user
                List<InvoiceFrame> resultByDateList = List.copyOf(filteredInvoices);
                this.RVAdapter.submitList(resultByDateList);
            }
            this.snackbar = Snackbar.make(findViewById(android.R.id.content), msgRes,
                            Snackbar.LENGTH_LONG).setAction("OK", v -> { });
            snackbar.show();
        }
    }

    /**
     * Show full invoice, including the rows and the headers for the selected invoice.
     * @param frame Selected InvoiceFrame
     */
    @SuppressLint("SetTextI18n")
    public void showFullInvoice(InvoiceFrame frame) {
        if (frame == null) return;
        if (frame.isEmpty()) return;
        List<InvoiceRow> invoiceRows = this.database.getAllRowsByID(frame.getID());
        if (invoiceRows != null)  invoiceManagerDialog.displayInvoice(frame, invoiceRows);
    }

    public void setupFloatingButtonComposeInvoice() {
        FloatingActionButton actionButton = findViewById(R.id.invoice_compose_floating_button);
        actionButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, InvoiceComposingActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void setUpRemove() {
        ImageButton removeButton = findViewById(R.id.button_invoices_remove);
        removeButton.setOnClickListener(view -> {
            if (this.RVAdapter.getSelectedPositions().isEmpty())
                Toast.makeText(this ,"Select one or more invoices",
                        Toast.LENGTH_SHORT).show();
            else removeSelectedInvoices();
        });
    }

    private void setupEditInvoice() {
        ImageButton editButton = findViewById(R.id.button_edit_selected_invoice);

        editButton.setOnClickListener(v -> {
            Set<Integer> temp = this.RVAdapter.getSelectedPositions();
            if (temp != null && temp.size() == 1) {
                int selectedIndex = temp.iterator().next();
                InvoiceFrame SelectedFrame = allInvoiceFrames.get(selectedIndex);

                if (SelectedFrame != null) {
                    Intent intent = new Intent(this.getBaseContext(), InvoiceComposingActivity.class);
                    intent.putExtra("InvoiceFrameID", SelectedFrame.getID());
                    startActivity(intent);
                    finish();
                }
            }
            else if (temp != null && temp.size() != 1)
                displaySnackBar("Select one invoice for edit");
        });
    }

    /**
     * Inflates the menu options in the toolbar.
     * @param menu The menu to be inflated.
     * @return True if the menu was successfully created.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_invoice_manager, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Handles menu item selection.
     * @param m The selected menu item.
     * @return True if the action was handled.
     */
    @SuppressLint("NotifyDataSetChanged")
    @Override
    public boolean onOptionsItemSelected(MenuItem m) {
        if (m.getItemId() == R.id.home_info) {
            Toast.makeText(this, "click on info", Toast.LENGTH_SHORT).show();
            return true;
        }
        if (m.getItemId() == R.id.item_manager_home) {
            finish();
            return true;
        }
        if (m.getItemId() == R.id.invoice_manager_invoice_share) {
            if (this.RVAdapter.getSelectedPositions().size() == 1) {
                for (Integer single : this.RVAdapter.getSelectedPositions()) {
                    InvoiceFrame invoiceFrame = allInvoiceFrames.get(single);
                    invoiceManagerDialog.shareInvoiceFrame(invoiceFrame,
                            database.getAllRowsByID(invoiceFrame.getID()));
                }
            }
            else if (this.RVAdapter.getSelectedPositions().isEmpty())
                Toast.makeText(this,
                        "No selected invoice to share", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this,
                        "Only one invoice to share", Toast.LENGTH_SHORT).show();
            return true;
        }
        if (m.getItemId() == R.id.invoice_manager_print_selected) {
            if (this.RVAdapter.getSelectedPositions().size() == 1) {
                for (Integer single : this.RVAdapter.getSelectedPositions()) {
                    InvoiceFrame invoiceFrame = allInvoiceFrames.get(single);
                    invoiceManagerDialog.printInvoiceFrame(invoiceFrame,
                            database.getAllRowsByID(invoiceFrame.getID()));
                }
            }
            else if (this.RVAdapter.getSelectedPositions().isEmpty())
                Toast.makeText(this,
                        "No selected invoice to print", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this,
                        "Only one invoice to print", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(m);
    }
}