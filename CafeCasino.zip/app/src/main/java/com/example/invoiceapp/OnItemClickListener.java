package com.example.invoiceapp;

/**
 * Interface definition for a callback to be invoked when an item in a
 * RecyclerView is clicked.
 * */
public interface OnItemClickListener {

    /**
     * Called when an item has been clicked.
     * @param position The position of the clicked item in the adapter.
     */
    void onItemClick(int position);
}