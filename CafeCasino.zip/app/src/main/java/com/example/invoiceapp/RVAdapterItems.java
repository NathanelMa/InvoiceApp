package com.example.invoiceapp;

import android.annotation.SuppressLint;
import androidx.annotation.NonNull;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Adapter for displaying InvoiceItem in a RecyclerView.
 * This adapter binds a list of items to views that are displayed within a RecyclerView.
 * Also, will handle selected InvoiceItem by user. Use method getSelectedItems().
 * NOTE: The list of item must not be a copy. (Reference to the original instance)
 */

public class RVAdapterItems extends
        RecyclerView.Adapter<RVAdapterItems.ViewHolder> {

    private final Context context;
    private final List<Item> itemsList;  // All current InvoiceItems (Reference)
    private final Set<Integer> selectedItemsPos; // Selected by user. LinkedHashSet prevent dup.
    private final boolean showQuantity; // Optional for display InvoiceRow (extend InvoiceItem)

    private static NumberFormat integerFormat;
    private static NumberFormat serialFormat;
    private static NumberFormat currencyFormat;

    private OnItemClickListener onItemClickListener = null;
    private OnItemLongClickListener onItemLongClickListener = null;

    /**
     * Set a listener for item click events.
     * @param listener The listener to handle item clicks.
     */
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    /**
     * Set a listener for item long click events.
     * @param listener The listener to handle item long clicks.
     */
    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.onItemLongClickListener = listener;
    }

    /**
     * Initialize the dataset of the Adapter.
     * @param invoiceItemList The list of items to be displayed (As Reference, not copy).
     * @param context The application context.
     * @param showQuantity Only if the list of items contain type of InvoiceRow.
     */
    public RVAdapterItems(List<Item> invoiceItemList,
                          Context context, boolean showQuantity) {
        this.showQuantity = showQuantity;
        this.itemsList = invoiceItemList;
        this.context = context;
        this.selectedItemsPos = new LinkedHashSet<>();
        currencyFormat = NumberFormat.getCurrencyInstance(Locale.getDefault());
        integerFormat = NumberFormat.getIntegerInstance(Locale.getDefault());
        currencyFormat.setMaximumFractionDigits(2); // Format example: 1,000.00 ; 1.000.00
        serialFormat = new DecimalFormat("0000000000");
    }

    /**
     * Creates new views (invoked by the layout manager).
     * @param holder The parent ViewGroup.
     * @param position The view type position.
     * @return A new ViewHolder that holds a view of the given type.
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup holder, int position) {
        View view = LayoutInflater.from(context).
                inflate(R.layout.item_recycler_view, holder, false);
        return new ViewHolder(view);
    }

    /**
     * Replace the contents of a view (invoked by the layout manager).
     * @param holder The ViewHolder instance.
     * @param position The position of the Item within the item list.
     */
    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        // Get element from dataset at this position and replace the
        // contents of the view with that element.

        if (position < 0 || position >= itemsList.size()) return;
        Item item = itemsList.get(position);
        if (item.isEmpty()) return;

        holder.item_name.setText(item.getName());
        holder.item_description.setText(item.getDescription());
        holder.item_id.setText("#" + serialFormat.format(item.getID()));
        holder.item_value.setText(currencyFormat.format(item.getValue()));

        // Set selection action: Add element to the selection list or remove it.
        if (selectedItemsPos.contains(position))
            holder.itemView.setBackgroundColor
                    (context.getResources().getColor(R.color.Cornsilk));
        else
            holder.itemView.setBackgroundColor
                    (context.getResources().getColor(R.color.White));

        // Set listener for selected item
        holder.itemView.setOnClickListener(v -> {
            boolean wasSelected = this.selectedItemsPos.contains(position);
            if (wasSelected) this.selectedItemsPos.remove(position);
            else this.selectedItemsPos.add(position);
            notifyItemChanged(position);
        });
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     * @return The number of items available.
     */
    @Override
    public int getItemCount() {
        return itemsList.size();
    }

    /**
     * Will return selected items by the user.
     * NOTE: After calling this method, will clear the list of selected items.
     * @return List of all selected items (Type InvoiceItem)
     */
    public List<Item> getSelectedItems() {
        List<Item> selected = new ArrayList<>();
        for (Integer pos : selectedItemsPos) {
            if (pos >= 0 && pos < itemsList.size()) selected.add(itemsList.get(pos));
            notifyItemChanged(pos);
        }
        return selected;
    }

    public void clearSelection() {
        // Clear the ref selected data set
        selectedItemsPos.clear();
    }

    /**
     * Will return single selected item. If non or more than one selected by the user,
     * it will return null object.
     * @return Selected item by user.
     */
    public Item getSelectedItem() {
        if (selectedItemsPos.size() == 1) return getSelectedItems().get(0);
        return null;
    }

    /** ViewHolder class for caching view references */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView item_name;
        private final TextView item_id;
        private final TextView item_description;
        private final TextView item_value;

        /**
         * Constructor that initializes the UI components for each Item.
         * @param itemView The root view of the Item layout.
         */
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.item_name = itemView.findViewById(R.id.RV_item_name);
            this.item_id = itemView.findViewById(R.id.RV_item_ID);
            this.item_description = itemView.findViewById(R.id.RV_item_description);
            this.item_value = itemView.findViewById(R.id.RV_item_value);
        }
    }
}
