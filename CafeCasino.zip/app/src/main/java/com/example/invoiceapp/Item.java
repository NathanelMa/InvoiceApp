package com.example.invoiceapp;

import androidx.annotation.NonNull;
import java.util.Objects;

public class Item implements Comparable<Item> {

    /**
     * Represents an item in an invoice, containing an ID, name, description, and value.
     */

    private final long ID;  // Unique ID item as in the database
    private final String name;  // Item name as in database
    private final String description; // Item description as in database
    private final double value; // Item value as in database

    public static final int ITEM_NAME_MAX_LEN = 50;
    public static final int ITEM_DESCRIPTION_MAX_LEN = 50;

    /**
     * Item composing raw constructor, without any validation for data.
     * @param ID unique ID for the item as in database.
     * @param name Name for the item. See ITEM_NAME_MAX_LEN
     * @param description Description for the item. See ITEM_DESCRIPTION_MAX_LEN
     * @param value Value (Price) for the item. Greater than 0.
     */
    public Item(long ID, @NonNull String name, String description, double value) {
        this.name = name;
        this.description = description;
        this.value = value;
        this.ID = ID;
    }

    /**
     * @return Get the unique item ID
     */
    public long getID() {
        return this.ID;
    }

    /**
     * @return Get the item name
     */
    public String getName() {
        return this.name;
    }

    /**
     * @return Get the description item
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * @return Get the item price
     */
    public double getValue() {
        return this.value;
    }

    public boolean isEmpty() {
        return this.getName().isEmpty();
    }

    @NonNull
    @Override
    public String toString() {
        return getName() + ", " + getValue();
    }

    /**
     * Will check valid item data: Valid name and description (no signs), and valid
     * (float or integer) price (value) of the item.
     * INVALID_ITEM_NAME, INVALID_ITEM_DESCRIPTION, INVALID_ITEM_VALUE (String)
     * Else, it will return a new instance of an item.
     * NOTE: The new item without an ID (0)
     * @return (Item) new item, else will return the value for invalid error.
     */
    public static Object checkValidData(String name, String description, String value) {
        return checkValidData(name, description, value, 0);
    }

    /**
     * Will check valid item data: Valid name and description (no signs), and valid
     * (float or integer) price (value) of the item.
     * INVALID_ITEM_NAME, INVALID_ITEM_DESCRIPTION, INVALID_ITEM_VALUE (String)
     * Else, it will return a new instance of an item.
     * NOTE: The new item is with the same given ID
     * @return (Item) new item, else will return the value for invalid error.
     */
    public static Object checkValidData(String name, String description, String value, long ID) {
        final String INVALID_ITEM_NAME = "Invalid item name";
        final String INVALID_ITEM_NAME_LEN = "Invalid item name length";
        final String INVALID_ITEM_DESCRIPTION = "Invalid item description";
        final String INVALID_ITEM_DESCRIPTION_LEN = "Invalid item description length";
        final String INVALID_ITEM_VALUE = "Invalid item value";

        if (name == null || name.trim().isEmpty() || !name.matches("^[a-zA-Z0-9 ]+$"))
            return INVALID_ITEM_NAME;
        if (name.length() > ITEM_NAME_MAX_LEN) return INVALID_ITEM_NAME_LEN;

        if (description == null
                || description.trim().isEmpty()
                || !description.matches("^[a-zA-Z0-9,. ]+$"))
            return INVALID_ITEM_DESCRIPTION;
        if (description.length() > ITEM_DESCRIPTION_MAX_LEN) return INVALID_ITEM_DESCRIPTION_LEN;

        double price;
        try {
            price = Double.parseDouble(value);
            if (price <= 0) {
                return INVALID_ITEM_VALUE; // Must by positive
            }
        } catch (NumberFormatException e) {
            return INVALID_ITEM_VALUE;
        }
        return new Item(ID, name, description, price);
    }

    @Override
    public int compareTo(Item invoiceItem) {
        return this.name.compareToIgnoreCase(invoiceItem.getName());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Item)) return false;
        Item item = (Item) o;
        return getID() == item.getID();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getID());
    }
}
