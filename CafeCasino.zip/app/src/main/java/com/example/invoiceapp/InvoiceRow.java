package com.example.invoiceapp;

import androidx.annotation.NonNull;

public class InvoiceRow implements Comparable<Item> {

    private final long invoiceID;
    private final Item item;
    private int quantity;
    private double totalPrice; // Total price as for the day of composing the invoice row.

    /**
     * Compose invoice row, without any validation for data.
     */
    public InvoiceRow(long invoiceID, int quantity, Item rowItem) {
        this.quantity = quantity;
        this.invoiceID = invoiceID;
        this.item = rowItem;
        updateTotalPrice();
    }

    public long getItemID() {
        return this.item.getID();
    }

    public String getItemName() {
        return item.getName();
    }

    public String getItemDescription() {
        return this.item.getDescription();
    }

    public double getItemValue() {
        return this.item.getValue();
    }

    ///////////////////////////////////////////////////

    public double getTotalRowValue() {
        return this.totalPrice;
    }

    public long getInvoiceID() {
        return this.invoiceID;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public boolean isEmpty() {
        return getQuantity() <= 0;
    }


    ///////////////////////////////////////////////////

    private void updateTotalPrice() {
        this.totalPrice = this.item.getValue() * this.quantity;
    }

    public void addQuantity(int add) {
        this.quantity += add;
        updateTotalPrice();
    }

    public void reduceQuantity() {
        if (quantity > 0) {
            this.quantity--;
            updateTotalPrice();
        }
    }

    ///////////////////////////////////////////////////

    @NonNull
    @Override
    public String toString() {
        return "#" + getInvoiceID() + " #" + getItemID() + " " + getItemName() + " " + getQuantity() + " " + getTotalRowValue();
    }

    /**
     * Comparing due to the total price for row.
     * @param other Other InvoiceItem type InvoiceRow
     * @return Comparable integer values
     */
    @Override
    public int compareTo(Item other) {
        return Long.compare(getItemID(), other.getID());
    }

    public int compareTo(InvoiceRow other) {
        return Long.compare(getInvoiceID(), other.getInvoiceID());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InvoiceRow other = (InvoiceRow) o;
        return this.getItemID() == other.getItemID();
    }


}
